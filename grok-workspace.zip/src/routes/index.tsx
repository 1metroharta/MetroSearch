import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/")({ component: Home });

declare global {
  interface Window {
    MetroSearch?: { mount: (el: HTMLElement) => void };
  }
}

function Home() {
  useEffect(() => {
    let cancelled = false;
    if (!document.getElementById("metro-css")) {
      const link = document.createElement("link");
      link.id = "metro-css";
      link.rel = "stylesheet";
      link.href = "/metro/app.css";
      document.head.appendChild(link);
    }
    const start = () => {
      if (cancelled) return;
      const el = document.getElementById("metro-root");
      if (el && window.MetroSearch) window.MetroSearch.mount(el);
    };
    if (window.MetroSearch) {
      start();
      return () => {
        cancelled = true;
      };
    }
    let script = document.querySelector<HTMLScriptElement>("script[data-metro]");
    if (!script) {
      script = document.createElement("script");
      script.src = "/metro/app.js";
      script.dataset.metro = "1";
      script.onload = start;
      document.body.appendChild(script);
    } else {
      script.addEventListener("load", start);
    }
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div id="metro-root">
      <main style={{ padding: "32px 20px", fontFamily: "Manrope, Segoe UI, sans-serif" }}>
        <p style={{ letterSpacing: "0.14em", textTransform: "uppercase", fontSize: "12px" }}>Линия M</p>
        <h1 style={{ fontSize: "40px", margin: "8px 0" }}>MetroSearch</h1>
        <p>Поиск по открытому интернету: сайты, картинки, новости и карты.</p>
      </main>
    </div>
  );
}
