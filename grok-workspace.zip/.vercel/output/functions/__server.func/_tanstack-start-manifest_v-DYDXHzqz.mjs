//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DYDXHzqz.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BQvJPxR4.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BQvJPxR4.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DF2hOm51.js"]
	}
} });
//#endregion
export { tsrStartManifest };
