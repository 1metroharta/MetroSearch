import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CaJc6qxG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		if (!document.getElementById("metro-css")) {
			const link = document.createElement("link");
			link.id = "metro-css";
			link.rel = "stylesheet";
			link.href = "/metro/app.css";
			document.head.appendChild(link);
		}
		const start = () => {
			if (cancelled) return;
			const el = document.getElementById("metro-root");
			if (el && window.MetroSearch) window.MetroSearch.mount(el);
		};
		if (window.MetroSearch) {
			start();
			return () => {
				cancelled = true;
			};
		}
		let script = document.querySelector("script[data-metro]");
		if (!script) {
			script = document.createElement("script");
			script.src = "/metro/app.js";
			script.dataset.metro = "1";
			script.onload = start;
			document.body.appendChild(script);
		} else script.addEventListener("load", start);
		return () => {
			cancelled = true;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		id: "metro-root",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			style: {
				padding: "32px 20px",
				fontFamily: "Manrope, Segoe UI, sans-serif"
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					style: {
						letterSpacing: "0.14em",
						textTransform: "uppercase",
						fontSize: "12px"
					},
					children: "Линия M"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					style: {
						fontSize: "40px",
						margin: "8px 0"
					},
					children: "MetroSearch"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Поиск по открытому интернету: сайты, картинки, новости и карты." })
			]
		})
	});
}
//#endregion
export { Home as component };
